import streamlit as st
import pandas as pd

# ----------------------------------------------------------------------
# Page config
# ----------------------------------------------------------------------
st.set_page_config(
    page_title="Smart Waste Segregation",
    page_icon="♻️",
    layout="centered"
)

# ----------------------------------------------------------------------
# Waste knowledge base
# Each item maps to a category: "Wet", "Dry", or "Recyclable"
# ----------------------------------------------------------------------
WASTE_DB = {
    # Wet / Organic waste
    "banana peel": "Wet", "apple core": "Wet", "vegetable peel": "Wet",
    "fruit peel": "Wet", "food waste": "Wet", "leftover food": "Wet",
    "tea bag": "Wet", "tea leaves": "Wet", "coffee grounds": "Wet",
    "egg shell": "Wet", "eggshell": "Wet", "meat scraps": "Wet",
    "fish bones": "Wet", "bones": "Wet", "rice": "Wet", "dal": "Wet",
    "curry": "Wet", "leaves": "Wet", "garden waste": "Wet",
    "flowers": "Wet", "plant trimmings": "Wet", "rotten food": "Wet",
    "spoiled fruit": "Wet", "spoiled vegetable": "Wet", "bread": "Wet",
    "milk": "Wet", "curd": "Wet", "yogurt": "Wet",

    # Dry / Non-recyclable waste
    "tissue paper": "Dry", "used tissue": "Dry", "napkin": "Dry",
    "cigarette butt": "Dry", "diaper": "Dry", "sanitary pad": "Dry",
    "thermocol": "Dry", "styrofoam": "Dry", "broken ceramic": "Dry",
    "broken glass": "Dry", "rubber": "Dry", "leather": "Dry",
    "dust": "Dry", "sweepings": "Dry", "wrapper": "Dry",
    "chips packet": "Dry", "chip packet": "Dry", "gum": "Dry",
    "chewing gum": "Dry", "cotton": "Dry", "cotton swab": "Dry",
    "hair": "Dry", "broken toy": "Dry", "shoe": "Dry", "rags": "Dry",
    "cloth": "Dry", "old clothes": "Dry", "ash": "Dry",

    # Recyclable waste
    "plastic bottle": "Recyclable", "plastic bag": "Recyclable",
    "plastic cup": "Recyclable", "plastic container": "Recyclable",
    "newspaper": "Recyclable", "magazine": "Recyclable",
    "cardboard": "Recyclable", "carton": "Recyclable",
    "paper": "Recyclable", "notebook": "Recyclable",
    "glass bottle": "Recyclable", "glass jar": "Recyclable",
    "metal can": "Recyclable", "aluminium can": "Recyclable",
    "aluminum foil": "Recyclable", "tin can": "Recyclable",
    "can": "Recyclable", "bottle": "Recyclable", "tin": "Recyclable",
    "steel can": "Recyclable", "iron scrap": "Recyclable",
    "old battery": "Recyclable", "e-waste": "Recyclable",
    "electronics": "Recyclable", "wire": "Recyclable",
    "cable": "Recyclable", "milk carton": "Recyclable",
    "pet bottle": "Recyclable", "tetra pack": "Recyclable",
}

CATEGORY_INFO = {
    "Wet": {
        "color": "#4CAF50",
        "icon": "🥬",
        "bin": "Green Bin",
        "desc": "Biodegradable kitchen and garden waste. Best composted to make natural fertilizer."
    },
    "Dry": {
        "color": "#9E9E9E",
        "icon": "🗑️",
        "bin": "Black Bin",
        "desc": "Non-recyclable, non-biodegradable waste. Goes directly to landfill disposal."
    },
    "Recyclable": {
        "color": "#2196F3",
        "icon": "♻️",
        "bin": "Blue Bin",
        "desc": "Materials like paper, plastic, glass, and metal that can be processed and reused."
    },
}


def classify_waste(item_name: str):
    """Rule-based classification using exact and partial keyword matching."""
    item_name = item_name.strip().lower()
    if not item_name:
        return None, None

    # 1. Exact match
    if item_name in WASTE_DB:
        return item_name, WASTE_DB[item_name]

    # 2. Partial / substring match (search both directions)
    for key, category in WASTE_DB.items():
        if key in item_name or item_name in key:
            return key, category

    # 3. Word-level match
    words = item_name.split()
    for key, category in WASTE_DB.items():
        key_words = key.split()
        if any(w in key_words for w in words):
            return key, category

    return None, None


# ----------------------------------------------------------------------
# Session state for history
# ----------------------------------------------------------------------
if "history" not in st.session_state:
    st.session_state.history = []

# ----------------------------------------------------------------------
# UI
# ----------------------------------------------------------------------
st.title("♻️ Smart Waste Segregation System")
st.caption("Type the name of a waste item to find out whether it is **Wet, Dry, or Recyclable**.")

col1, col2 = st.columns([4, 1])
with col1:
    item_input = st.text_input("Enter waste item name", placeholder="e.g. banana peel, plastic bottle, tissue paper")
with col2:
    st.write("")
    st.write("")
    classify_clicked = st.button("Classify", use_container_width=True)

if classify_clicked or item_input:
    matched_key, category = classify_waste(item_input)

    if category:
        info = CATEGORY_INFO[category]
        st.markdown(
            f"""
            <div style="padding:20px; border-radius:12px; background-color:{info['color']}22;
                        border:2px solid {info['color']}; margin-top:10px;">
                <h2 style="color:{info['color']}; margin:0;">{info['icon']} {category} Waste</h2>
                <p style="margin:6px 0 0 0;"><b>Recommended bin:</b> {info['bin']}</p>
                <p style="margin:6px 0 0 0;">{info['desc']}</p>
            </div>
            """,
            unsafe_allow_html=True
        )
        if item_input.strip().lower() != matched_key:
            st.caption(f"Matched with known item: '{matched_key}'")

        if classify_clicked:
            st.session_state.history.append({"Item": item_input.strip(), "Category": category})
    else:
        st.warning("Sorry, this item isn't in our database yet. Try a different name or check spelling.")

# ----------------------------------------------------------------------
# History table
# ----------------------------------------------------------------------
if st.session_state.history:
    st.subheader("📜 Classification History")
    df = pd.DataFrame(st.session_state.history)
    st.dataframe(df, use_container_width=True, hide_index=True)

    counts = df["Category"].value_counts()
    st.subheader("📊 Summary")
    bcol1, bcol2, bcol3 = st.columns(3)
    bcol1.metric("Wet", int(counts.get("Wet", 0)))
    bcol2.metric("Dry", int(counts.get("Dry", 0)))
    bcol3.metric("Recyclable", int(counts.get("Recyclable", 0)))

    if st.button("Clear History"):
        st.session_state.history = []
        st.rerun()

# ----------------------------------------------------------------------
# Sidebar
# ----------------------------------------------------------------------
with st.sidebar:
    st.header("ℹ️ About")
    st.write(
        "This app uses a rule-based keyword matching system to classify "
        "common waste items into three categories: Wet, Dry, and Recyclable, "
        "helping promote correct waste segregation at the source."
    )
    st.header("📂 Categories")
    for cat, info in CATEGORY_INFO.items():
        st.markdown(f"{info['icon']} **{cat}** — {info['bin']}")

    st.header("🔍 Browse Database")
    search_cat = st.selectbox("Filter by category", ["All"] + list(CATEGORY_INFO.keys()))
    items_df = pd.DataFrame(
        [{"Item": k.title(), "Category": v} for k, v in sorted(WASTE_DB.items())]
    )
    if search_cat != "All":
        items_df = items_df[items_df["Category"] == search_cat]
    st.dataframe(items_df, use_container_width=True, hide_index=True, height=300)
